import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ImagePlus, X, MapPin, Loader2, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import PageTransition from "@/components/PageTransition";
import { toast } from "sonner";

const categories = [
  "মোবাইল", "ইলেকট্রনিক্স", "গাড়ি", "বাড়ি/ফ্ল্যাট", "পোশাক",
  "আসবাবপত্র", "চাকরি", "গেমিং", "বই", "অন্যান্য",
];

const divisions = ["ঢাকা", "চট্টগ্রাম", "রাজশাহী", "সিলেট", "খুলনা", "বরিশাল", "রংপুর", "ময়মনসিংহ"];

const PostAd = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [mode, setMode] = useState<"sell" | "exchange" | "free">("sell");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [wantInReturn, setWantInReturn] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [imageFiles, setImageFiles] = useState<{ file: File; preview: string }[]>([]);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [isBoosted, setIsBoosted] = useState(false);
  const [showBoostConfirm, setShowBoostConfirm] = useState(false);
  const [userPoints, setUserPoints] = useState(0);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("points").eq("user_id", user.id).single().then(({ data }) => {
      if (data) setUserPoints(data.points);
    });
  }, [user]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const remaining = 5 - imageFiles.length;
    const selected = Array.from(files).slice(0, remaining);
    const newImages = selected.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
    }));
    setImageFiles((prev) => [...prev, ...newImages]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeImage = (index: number) => {
    setImageFiles((prev) => {
      URL.revokeObjectURL(prev[index].preview);
      return prev.filter((_, i) => i !== index);
    });
  };

  const uploadImages = async (): Promise<string[]> => {
    if (!user) return [];
    const urls: string[] = [];
    for (const img of imageFiles) {
      const ext = img.file.name.split(".").pop() || "jpg";
      const path = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from("post-images").upload(path, img.file);
      if (error) {
        console.error("Upload error:", error);
        continue;
      }
      const { data: urlData } = supabase.storage.from("post-images").getPublicUrl(path);
      urls.push(urlData.publicUrl);
    }
    return urls;
  };

  const handleSubmit = async () => {
    if (!user) {
      toast.error("পোস্ট করতে প্রথমে লগইন করুন।");
      navigate("/login");
      return;
    }
    if (!title.trim() || !category) {
      toast.error("শিরোনাম ও ক্যাটাগরি আবশ্যক।");
      return;
    }

    setSubmitting(true);
    setUploading(imageFiles.length > 0);

    try {
      const imageUrls = await uploadImages();
      setUploading(false);

      const { error } = await supabase.from("posts").insert({
        user_id: user.id,
        title: title.trim(),
        description: description.trim(),
        category,
        mode,
        price: mode === "sell" ? parseFloat(price) || 0 : 0,
        want_in_return: mode === "exchange" ? wantInReturn.trim() : "",
        location,
        images: imageUrls,
        status: "pending",
        is_boosted: isBoosted,
        boost_expires_at: isBoosted ? new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() : null,
      });

      if (error) throw error;

      // Deduct points if boosted
      if (isBoosted) {
        await supabase.from("profiles").update({ points: userPoints - 100 }).eq("user_id", user.id);
      }

      if (error) throw error;

      toast.success("পোস্ট সাবমিট হয়েছে! অ্যাডমিন অনুমোদনের জন্য অপেক্ষা করুন।");
      navigate("/");
    } catch (err: any) {
      toast.error("পোস্ট করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।");
      console.error(err);
    } finally {
      setSubmitting(false);
      setUploading(false);
    }
  };

  return (
    <PageTransition className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="text-foreground">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-lg font-semibold text-foreground">নতুন পোস্ট তৈরি করুন</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-lg">
        {/* Post Mode */}
        <div className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">পোস্টের ধরন</label>
          <div className="flex gap-2">
            {([
              { value: "sell", label: "বিক্রি", style: "badge-sell" },
              { value: "exchange", label: "এক্সচেঞ্জ", style: "badge-exchange" },
              { value: "free", label: "ফ্রি", style: "badge-free" },
            ] as const).map((m) => (
              <button
                key={m.value}
                onClick={() => setMode(m.value)}
                className={`px-4 py-2 rounded-lg text-sm font-medium border-2 transition-all ${
                  mode === m.value
                    ? `${m.style} border-transparent`
                    : "bg-card text-foreground border-border"
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Images */}
        <div className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">ছবি যোগ করুন (সর্বোচ্চ ৫টি)</label>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleImageSelect}
          />
          <div className="flex gap-2 flex-wrap">
            {imageFiles.map((img, i) => (
              <div key={i} className="relative w-20 h-20 rounded-lg overflow-hidden border border-border">
                <img src={img.preview} alt="" className="w-full h-full object-cover" />
                <button
                  onClick={() => removeImage(i)}
                  className="absolute top-0.5 right-0.5 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center"
                >
                  <X size={12} />
                </button>
              </div>
            ))}
            {imageFiles.length < 5 && (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-20 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center text-muted-foreground hover:border-primary hover:text-primary transition-colors"
              >
                <ImagePlus size={20} />
                <span className="text-[10px] mt-0.5">যোগ করুন</span>
              </button>
            )}
          </div>
        </div>

        {/* Title */}
        <div className="mb-4">
          <label className="text-sm font-medium text-foreground mb-1.5 block">শিরোনাম</label>
          <input
            type="text"
            placeholder="আপনার পণ্যের নাম লিখুন"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        {/* Description */}
        <div className="mb-4">
          <label className="text-sm font-medium text-foreground mb-1.5 block">বিবরণ</label>
          <textarea
            placeholder="পণ্যের বিস্তারিত লিখুন..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring resize-none"
          />
        </div>

        {mode === "sell" && (
          <div className="mb-4">
            <label className="text-sm font-medium text-foreground mb-1.5 block">মূল্য (৳)</label>
            <input
              type="number"
              placeholder="0"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        )}

        {mode === "exchange" && (
          <div className="mb-4">
            <label className="text-sm font-medium text-foreground mb-1.5 block">বিনিময়ে যা চান</label>
            <input
              type="text"
              placeholder="যেমন: iPhone 14, Yamaha R15..."
              value={wantInReturn}
              onChange={(e) => setWantInReturn(e.target.value)}
              className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        )}

        {/* Category */}
        <div className="mb-4">
          <label className="text-sm font-medium text-foreground mb-1.5 block">ক্যাটাগরি</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
          >
            <option value="">ক্যাটাগরি নির্বাচন করুন</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        {/* Boost Toggle */}
        <div className="mb-4 bg-card rounded-xl border border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap size={18} className="text-yellow-500" />
              <div>
                <p className="text-sm font-medium text-foreground">পোস্ট বুস্ট</p>
                <p className="text-[11px] text-muted-foreground">প্রতিদিন ১০০ পয়েন্ট</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                if (!isBoosted) {
                  if (userPoints < 100) {
                    toast.error("বুস্ট করতে কমপক্ষে ১০০ পয়েন্ট প্রয়োজন।");
                    return;
                  }
                  setShowBoostConfirm(true);
                } else {
                  setIsBoosted(false);
                }
              }}
              className={`w-12 h-6 rounded-full transition-colors relative ${isBoosted ? "bg-green-500" : "bg-muted-foreground/30"}`}
            >
              <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${isBoosted ? "translate-x-6" : "translate-x-0.5"}`} />
            </button>
          </div>
        </div>

        {/* Boost Confirmation Modal */}
        {showBoostConfirm && (
          <div className="fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-4">
            <div className="bg-card rounded-2xl border border-border p-6 max-w-sm w-full">
              <p className="text-sm text-foreground font-medium mb-4">
                আপনি কি প্রতিদিন ১০০ পয়েন্ট খরচ করে এই পোস্টটি বুস্ট করতে চান?
              </p>
              <p className="text-xs text-muted-foreground mb-4">আপনার বর্তমান পয়েন্ট: {userPoints}</p>
              <div className="flex gap-2">
                <button
                  onClick={() => { setShowBoostConfirm(false); }}
                  className="flex-1 py-2 rounded-lg border border-border text-sm font-medium text-foreground"
                >
                  বাতিল
                </button>
                <button
                  onClick={() => { setIsBoosted(true); setShowBoostConfirm(false); }}
                  className="flex-1 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold"
                >
                  নিশ্চিত
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Location */}
        <div className="mb-6">
          <label className="text-sm font-medium text-foreground mb-1.5 block">
            <MapPin size={14} className="inline mr-1" />
            অবস্থান
          </label>
          <select
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring"
          >
            <option value="">বিভাগ নির্বাচন করুন</option>
            {divisions.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={submitting}
          className="w-full bg-primary text-primary-foreground py-3 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              {uploading ? "ছবি আপলোড হচ্ছে..." : "পোস্ট হচ্ছে..."}
            </>
          ) : (
            "পোস্ট করুন"
          )}
        </button>
        <p className="text-xs text-muted-foreground text-center mt-2">
          পোস্ট অ্যাডমিন অনুমোদনের পরে প্রদর্শিত হবে
        </p>
      </div>
    </PageTransition>
  );
};

export default PostAd;
