import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import PageTransition from "@/components/PageTransition";
import AdminStats from "@/components/admin/AdminStats";
import AdminPosts from "@/components/admin/AdminPosts";
import AdminUsers from "@/components/admin/AdminUsers";
import AdminNotices from "@/components/admin/AdminNotices";
import AdminChat from "@/components/admin/AdminChat";
import AdminReports from "@/components/admin/AdminReports";
import {
  ArrowLeft, BarChart3, FileText, Users, Bell, MessageSquare, AlertTriangle, Shield
} from "lucide-react";

type Tab = "overview" | "posts" | "users" | "notices" | "chat" | "reports";

const AdminPanel = () => {
  const navigate = useNavigate();
  const { user, loading, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>("overview");

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      navigate("/");
    }
  }, [loading, user, isAdmin, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <Shield size={40} className="mx-auto mb-3 animate-pulse text-primary" />
          <p className="text-sm">লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  if (!user || !isAdmin) {
    return null;
  }


  const tabs: { key: Tab; label: string; icon: typeof FileText }[] = [
    { key: "overview", label: "ওভারভিউ", icon: BarChart3 },
    { key: "posts", label: "পোস্ট", icon: FileText },
    { key: "users", label: "ইউজার", icon: Users },
    { key: "notices", label: "নোটিশ", icon: Bell },
    { key: "chat", label: "সাপোর্ট", icon: MessageSquare },
    { key: "reports", label: "রিপোর্ট", icon: AlertTriangle },
  ];

  return (
    <PageTransition className="min-h-screen bg-background pb-6">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="text-foreground">
            <ArrowLeft size={20} />
          </button>
          <Shield size={18} className="text-primary" />
          <h1 className="text-lg font-semibold text-foreground">অ্যাডমিন ড্যাশবোর্ড</h1>
        </div>
        {/* Tabs */}
        <div className="container mx-auto px-4 flex gap-1 pb-2 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                activeTab === tab.key
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              <tab.icon size={14} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-4xl py-4">
        {activeTab === "overview" && (
          <div className="space-y-4">
            <AdminStats />
            <div className="bg-card rounded-xl border border-border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-2">দ্রুত অ্যাকশন</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {tabs.filter(t => t.key !== "overview").map((t) => (
                  <button
                    key={t.key}
                    onClick={() => setActiveTab(t.key)}
                    className="flex items-center gap-2 p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
                  >
                    <t.icon size={16} className="text-primary" />
                    <span className="text-sm text-foreground">{t.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        {activeTab === "posts" && <AdminPosts />}
        {activeTab === "users" && <AdminUsers />}
        {activeTab === "notices" && <AdminNotices />}
        {activeTab === "chat" && <AdminChat />}
        {activeTab === "reports" && <AdminReports />}
      </div>
    </PageTransition>
  );
};

export default AdminPanel;
