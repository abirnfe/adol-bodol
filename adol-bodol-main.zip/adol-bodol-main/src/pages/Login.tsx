import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Mail } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import PageTransition from "@/components/PageTransition";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError("Email or Password mismatch.");
    } else if (data.user) {
      // Check if admin and redirect accordingly
      const { data: isAdmin } = await supabase.rpc("has_role", {
        _user_id: data.user.id,
        _role: "admin",
      });
      navigate(isAdmin ? "/admin" : "/");
    }
    setLoading(false);
  };

  return (
    <PageTransition className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="px-4 py-2 rounded-2xl bg-green-600 inline-flex items-center justify-center mx-auto mb-3">
            <span className="text-white font-bold text-2xl">আদল-বদল</span>
          </div>
          <h1 className="text-2xl font-bold text-foreground">আদল-বদলে স্বাগতম</h1>
          <p className="text-muted-foreground text-sm mt-1">আপনার একাউন্টে লগইন করুন</p>
        </div>

        <form onSubmit={handleLogin} className="bg-card rounded-2xl border border-border p-6 shadow-sm">
          {error && (
            <div className="bg-destructive/10 text-destructive text-sm px-3 py-2 rounded-lg mb-4">{error}</div>
          )}
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">ইমেইল</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <span className="px-3 text-muted-foreground"><Mail size={16} /></span>
                <input
                  type="email"
                  placeholder="example@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 bg-transparent px-2 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">পাসওয়ার্ড</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="আপনার পাসওয়ার্ড"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none"
                  required
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="px-3 text-muted-foreground hover:text-foreground transition-colors">
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="text-right">
              <Link to="/forgot-password" className="text-xs text-primary hover:underline">পাসওয়ার্ড ভুলে গেছেন?</Link>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {loading ? "লগইন হচ্ছে..." : "লগইন করুন"}
            </button>
          </div>

          <div className="mt-6 text-center text-sm text-muted-foreground">
            একাউন্ট নেই?{" "}
            <Link to="/signup" className="text-primary font-medium hover:underline">সাইন আপ করুন</Link>
          </div>
        </form>
      </div>
    </PageTransition>
  );
};

export default Login;
