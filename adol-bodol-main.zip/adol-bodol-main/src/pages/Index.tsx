import SearchBar from "@/components/SearchBar";
import CategoryGrid from "@/components/CategoryGrid";
import FeaturedPosts from "@/components/FeaturedPosts";
import PostFeed from "@/components/PostFeed";
import BottomNav from "@/components/BottomNav";
import Header from "@/components/Header";
import PageTransition from "@/components/PageTransition";

const Index = () => {
  return (
    <PageTransition className="min-h-screen bg-background pb-20 md:pb-0">
      <Header />
      <SearchBar />
      <CategoryGrid />
      <FeaturedPosts />
      <div className="container mx-auto px-4">
        <div className="border-t border-border" />
      </div>
      <PostFeed />
      <BottomNav />
    </PageTransition>
  );
};

export default Index;
