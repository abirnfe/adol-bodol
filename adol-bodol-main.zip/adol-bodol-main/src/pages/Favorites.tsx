import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Heart, MapPin, Clock } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import PageTransition from "@/components/PageTransition";
import BottomNav from "@/components/BottomNav";

const Favorites = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("favorites");
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  return (
    <PageTransition className="min-h-screen bg-background pb-24">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="text-foreground">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-lg font-semibold text-foreground">পছন্দের তালিকা</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-lg py-8">
        {favorites.length === 0 ? (
          <div className="text-center py-16">
            <Heart size={48} className="mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">আপনার পছন্দের তালিকা খালি।</p>
            <Link to="/" className="text-primary text-sm font-medium hover:underline mt-2 inline-block">
              পোস্ট ব্রাউজ করুন
            </Link>
          </div>
        ) : (
          <p className="text-muted-foreground text-center">আপনার পছন্দের পোস্টগুলো এখানে দেখাবে।</p>
        )}
      </div>

      <BottomNav />
    </PageTransition>
  );
};

export default Favorites;
