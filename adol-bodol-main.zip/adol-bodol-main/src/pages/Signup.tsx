import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Eye, EyeOff, Mail, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import PageTransition from "@/components/PageTransition";
import { toast } from "sonner";

const Signup = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const refCode = searchParams.get("ref") || "";

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) { setError("পাসওয়ার্ড মিলছে না"); return; }
    if (password.length < 6) { setError("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে"); return; }

    setLoading(true);
    setError("");
    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { name, phone, referred_by: refCode },
        emailRedirectTo: window.location.origin,
      },
    });

    if (signUpError) {
      setError(signUpError.message);
      setLoading(false);
      return;
    }

    // If referral code exists, give points
    if (refCode && signUpData.user) {
      // Give new user 100 points
      await supabase.from("profiles").update({ points: 100, referred_by: refCode }).eq("user_id", signUpData.user.id);

      // Find referrer and give 50 points
      const { data: referrerProfiles } = await supabase
        .from("profiles")
        .select("user_id, points")
        .ilike("user_id", `${refCode}%`);

      if (referrerProfiles && referrerProfiles.length > 0) {
        const referrer = referrerProfiles[0];
        await supabase.from("profiles").update({ points: referrer.points + 50 }).eq("user_id", referrer.user_id);
      }
    }

    toast.success("সাইন আপ সফল! অনুগ্রহ করে আপনার ইমেইল চেক করুন।");
    navigate("/login");
    setLoading(false);
  };

  return (
    <PageTransition className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="px-4 py-2 rounded-2xl bg-green-600 inline-flex items-center justify-center mx-auto mb-3">
            <span className="text-white font-bold text-2xl">আদল-বদল</span>
          </div>
          <h1 className="text-2xl font-bold text-foreground">নতুন একাউন্ট তৈরি করুন</h1>
          <p className="text-muted-foreground text-sm mt-1">আদল-বদলে যোগ দিন</p>
          {refCode && (
            <p className="text-xs text-primary mt-1">🎁 রেফারেল কোড: {refCode} — সাইন আপে ১০০ পয়েন্ট পাবেন!</p>
          )}
        </div>

        <form onSubmit={handleSignup} className="bg-card rounded-2xl border border-border p-6 shadow-sm">
          {error && (
            <div className="bg-destructive/10 text-destructive text-sm px-3 py-2 rounded-lg mb-4">{error}</div>
          )}
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">আপনার নাম</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <span className="px-3 text-muted-foreground"><User size={16} /></span>
                <input type="text" placeholder="পূর্ণ নাম" value={name} onChange={(e) => setName(e.target.value)} className="flex-1 bg-transparent px-2 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" required />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">ইমেইল</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <span className="px-3 text-muted-foreground"><Mail size={16} /></span>
                <input type="email" placeholder="example@email.com" value={email} onChange={(e) => setEmail(e.target.value)} className="flex-1 bg-transparent px-2 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" required />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">মোবাইল নম্বর (ঐচ্ছিক)</label>
              <input type="tel" placeholder="01XXXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">পাসওয়ার্ড</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <input type={showPassword ? "text" : "password"} placeholder="নতুন পাসওয়ার্ড" value={password} onChange={(e) => setPassword(e.target.value)} className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="px-3 text-muted-foreground hover:text-foreground"><Eye size={16} /></button>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">পাসওয়ার্ড নিশ্চিত করুন</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <input type={showConfirm ? "text" : "password"} placeholder="আবার পাসওয়ার্ড দিন" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" required />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="px-3 text-muted-foreground hover:text-foreground"><Eye size={16} /></button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50">
              {loading ? "তৈরি হচ্ছে..." : "সাইন আপ করুন"}
            </button>
          </div>
          <div className="mt-6 text-center text-sm text-muted-foreground">
            ইতিমধ্যে একাউন্ট আছে?{" "}
            <Link to="/login" className="text-primary font-medium hover:underline">লগইন করুন</Link>
          </div>
        </form>
      </div>
    </PageTransition>
  );
};

export default Signup;
