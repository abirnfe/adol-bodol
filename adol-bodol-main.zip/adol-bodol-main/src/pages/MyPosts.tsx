import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Edit2, Trash2, Plus, Clock, CheckCircle, XCircle, Eye } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import PageTransition from "@/components/PageTransition";
import BottomNav from "@/components/BottomNav";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog";

const MyPosts = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const fetchPosts = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("posts")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setPosts(data || []);
    setLoading(false);
  };

  useEffect(() => {
    if (authLoading) return;
    if (!user) { navigate("/login"); return; }
    fetchPosts();
  }, [user, authLoading]);

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from("posts").delete().eq("id", deleteId).eq("user_id", user!.id);
    if (error) {
      toast.error("পোস্ট ডিলিট করা যায়নি।");
    } else {
      toast.success("পোস্ট ডিলিট হয়েছে!");
      setPosts(prev => prev.filter(p => p.id !== deleteId));
    }
    setDeleteId(null);
  };

  const statusBadge = (status: string) => {
    const map: Record<string, { label: string; className: string; icon: any }> = {
      pending: { label: "অপেক্ষমাণ", className: "bg-yellow-100 text-yellow-800", icon: Clock },
      approved: { label: "অনুমোদিত", className: "bg-green-100 text-green-800", icon: CheckCircle },
      rejected: { label: "প্রত্যাখ্যাত", className: "bg-red-100 text-red-800", icon: XCircle },
    };
    const s = map[status] || map.pending;
    const Icon = s.icon;
    return (
      <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full ${s.className}`}>
        <Icon size={10} /> {s.label}
      </span>
    );
  };

  if (authLoading || loading) {
    return (
      <PageTransition className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
      </PageTransition>
    );
  }

  return (
    <PageTransition className="min-h-screen bg-background pb-24">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/profile")} className="text-foreground"><ArrowLeft size={20} /></button>
          <h1 className="text-lg font-semibold text-foreground">আমার পোস্টসমূহ</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-lg mt-4">
        {posts.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Eye size={28} className="text-muted-foreground" />
            </div>
            <p className="text-foreground font-medium mb-1">আপনি কোনো পোস্ট করেন নাই</p>
            <p className="text-sm text-muted-foreground mb-4">এখনই আপনার প্রথম পোস্ট করুন!</p>
            <button
              onClick={() => navigate("/post")}
              className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg text-sm font-semibold inline-flex items-center gap-2"
            >
              <Plus size={16} /> পোস্ট করুন
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {posts.map(post => (
              <div key={post.id} className="bg-card rounded-xl border border-border overflow-hidden">
                <div className="flex" onClick={() => navigate(`/post/${post.id}`)} role="button">
                  {post.images?.[0] && (
                    <img src={post.images[0]} alt="" className="w-24 h-24 object-cover flex-shrink-0" />
                  )}
                  <div className="p-3 flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      {statusBadge(post.status)}
                      {post.is_boosted && <span className="text-[10px] bg-yellow-100 text-yellow-800 px-1.5 py-0.5 rounded-full font-medium">⚡ বুস্টেড</span>}
                    </div>
                    <h3 className="text-sm font-medium text-foreground line-clamp-1">{post.title}</h3>
                    <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{post.description}</p>
                    {post.mode === "sell" && post.price > 0 && (
                      <p className="text-sm font-bold text-primary mt-1">৳ {Number(post.price).toLocaleString()}</p>
                    )}
                    {post.rejection_reason && post.status === "rejected" && (
                      <p className="text-[11px] text-destructive mt-1">কারণ: {post.rejection_reason}</p>
                    )}
                  </div>
                </div>
                <div className="flex gap-2 px-3 pb-3">
                  <button
                    onClick={() => navigate(`/post/edit/${post.id}`)}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-secondary text-secondary-foreground py-2 rounded-lg text-xs font-medium"
                  >
                    <Edit2 size={12} /> এডিট
                  </button>
                  <button
                    onClick={() => setDeleteId(post.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-destructive/10 text-destructive py-2 rounded-lg text-xs font-medium"
                  >
                    <Trash2 size={12} /> ডিলিট
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>পোস্ট ডিলিট করুন</DialogTitle>
            <DialogDescription>আপনি কি নিশ্চিত এই পোস্টটি ডিলিট করতে চান? এটি পূর্বাবস্থায় ফেরানো যাবে না।</DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2">
            <button onClick={() => setDeleteId(null)} className="flex-1 py-2 rounded-lg border border-border text-sm font-medium text-foreground">বাতিল</button>
            <button onClick={handleDelete} className="flex-1 py-2 rounded-lg bg-destructive text-destructive-foreground text-sm font-semibold">ডিলিট</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <BottomNav />
    </PageTransition>
  );
};

export default MyPosts;
