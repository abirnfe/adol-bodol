import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, MapPin, Clock, Phone, MessageSquare, Share2, Flag, Heart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import PageTransition from "@/components/PageTransition";
import BottomNav from "@/components/BottomNav";

interface PostData {
  id: string;
  title: string;
  description: string | null;
  category: string;
  mode: string;
  price: number | null;
  location: string | null;
  want_in_return: string | null;
  images: string[] | null;
  created_at: string;
  user_id: string;
}

interface ProfileData {
  name: string;
  phone: string;
  whatsapp: string | null;
}

const PostDetails = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState<PostData | null>(null);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    if (!id) return;
    const fetchPost = async () => {
      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .eq("id", id)
        .single();
      if (error || !data) {
        setLoading(false);
        return;
      }
      setPost(data);

      const { data: profileData } = await supabase
        .from("profiles")
        .select("name, phone, whatsapp")
        .eq("user_id", data.user_id)
        .single();
      if (profileData) setProfile(profileData);
      setLoading(false);
    };
    fetchPost();
  }, [id]);

  const modeBadge = (mode: string) => {
    const styles: Record<string, string> = { sell: "badge-sell", exchange: "badge-exchange", free: "badge-free" };
    const labels: Record<string, string> = { sell: "বিক্রি", exchange: "এক্সচেঞ্জ", free: "ফ্রি" };
    return (
      <span className={`${styles[mode] || "badge-sell"} text-xs font-semibold px-3 py-1 rounded-full`}>
        {labels[mode] || mode}
      </span>
    );
  };

  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins} মিনিট আগে`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours} ঘণ্টা আগে`;
    return `${Math.floor(hours / 24)} দিন আগে`;
  };

  if (loading) {
    return (
      <PageTransition className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
      </PageTransition>
    );
  }

  if (!post) {
    return (
      <PageTransition className="min-h-screen bg-background flex flex-col items-center justify-center gap-4">
        <p className="text-lg text-muted-foreground">পোস্টটি পাওয়া যায়নি</p>
        <Link to="/" className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium">
          হোমে ফিরে যান
        </Link>
      </PageTransition>
    );
  }

  const images = post.images && post.images.length > 0
    ? post.images
    : ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&h=400&fit=crop"];

  const phoneNumber = profile?.whatsapp || profile?.phone || "";

  return (
    <PageTransition className="min-h-screen bg-background pb-24 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="text-foreground">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-base font-semibold text-foreground truncate mx-4">{post.title}</h1>
          <div className="flex items-center gap-2">
            <button className="text-muted-foreground hover:text-foreground p-1"><Share2 size={18} /></button>
            <button className="text-muted-foreground hover:text-destructive p-1"><Heart size={18} /></button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-2xl">
        {/* Image Gallery */}
        <div className="mt-4 rounded-xl overflow-hidden border border-border">
          <img
            src={images[activeImage]}
            alt={post.title}
            className="w-full h-64 sm:h-80 object-cover"
          />
          {images.length > 1 && (
            <div className="flex gap-2 p-2 overflow-x-auto bg-card">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={`w-16 h-16 rounded-lg overflow-hidden border-2 flex-shrink-0 ${
                    i === activeImage ? "border-primary" : "border-transparent"
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="mt-4 bg-card rounded-xl border border-border p-4">
          <div className="flex items-center justify-between mb-2">
            {modeBadge(post.mode)}
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock size={12} /> {timeAgo(post.created_at)}
            </span>
          </div>
          <h2 className="text-lg font-bold text-foreground">{post.title}</h2>

          {post.mode === "sell" && post.price !== null && (
            <p className="text-xl font-bold text-primary mt-1">৳ {post.price.toLocaleString()}</p>
          )}
          {post.mode === "exchange" && post.want_in_return && (
            <p className="text-sm text-accent mt-1">বিনিময়ে চাই: {post.want_in_return}</p>
          )}
          {post.mode === "free" && (
            <p className="text-sm text-green-600 font-semibold mt-1">ফ্রি</p>
          )}

          {post.location && (
            <p className="text-sm text-muted-foreground mt-2 flex items-center gap-1">
              <MapPin size={14} /> {post.location}
            </p>
          )}

          <p className="text-xs text-muted-foreground mt-1">ক্যাটাগরি: {post.category}</p>
        </div>

        {/* Description */}
        {post.description && (
          <div className="mt-3 bg-card rounded-xl border border-border p-4">
            <h3 className="text-sm font-semibold text-foreground mb-2">বিবরণ</h3>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{post.description}</p>
          </div>
        )}

        {/* Seller Info */}
        {profile && (
          <div className="mt-3 bg-card rounded-xl border border-border p-4">
            <h3 className="text-sm font-semibold text-foreground mb-3">বিক্রেতার তথ্য</h3>
            <p className="text-sm text-foreground font-medium">{profile.name}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-4 flex gap-3">
          {phoneNumber && (
            <>
              <a
                href={`tel:${phoneNumber}`}
                className="flex-1 bg-primary text-primary-foreground py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors"
              >
                <Phone size={16} /> কল করুন
              </a>
              <a
                href={`https://wa.me/${phoneNumber.replace(/\D/g, "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-green-600 text-white py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-green-700 transition-colors"
              >
                <MessageSquare size={16} /> WhatsApp
              </a>
            </>
          )}
        </div>

        {/* Report */}
        <button className="mt-3 w-full flex items-center justify-center gap-1 text-xs text-muted-foreground hover:text-destructive transition-colors py-2">
          <Flag size={12} /> এই পোস্টটি রিপোর্ট করুন
        </button>
      </div>

      <BottomNav />
    </PageTransition>
  );
};

export default PostDetails;
