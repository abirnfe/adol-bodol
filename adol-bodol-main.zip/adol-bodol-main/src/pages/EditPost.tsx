import { useState, useRef, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ImagePlus, X, MapPin, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import PageTransition from "@/components/PageTransition";
import { toast } from "sonner";

const categories = [
  "মোবাইল", "ইলেকট্রনিক্স", "গাড়ি", "বাড়ি/ফ্ল্যাট", "পোশাক",
  "আসবাবপত্র", "চাকরি", "গেমিং", "বই", "অন্যান্য",
];
const divisions = ["ঢাকা", "চট্টগ্রাম", "রাজশাহী", "সিলেট", "খুলনা", "বরিশাল", "রংপুর", "ময়মনসিংহ"];

const EditPost = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [mode, setMode] = useState<"sell" | "exchange" | "free">("sell");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [wantInReturn, setWantInReturn] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [existingImages, setExistingImages] = useState<string[]>([]);
  const [newImageFiles, setNewImageFiles] = useState<{ file: File; preview: string }[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id || !user) return;
    const fetchPost = async () => {
      const { data } = await supabase.from("posts").select("*").eq("id", id).eq("user_id", user.id).single();
      if (!data) { toast.error("পোস্ট পাওয়া যায়নি"); navigate("/my-posts"); return; }
      setMode(data.mode as any);
      setTitle(data.title);
      setDescription(data.description || "");
      setPrice(data.price?.toString() || "");
      setWantInReturn(data.want_in_return || "");
      setCategory(data.category);
      setLocation(data.location || "");
      setExistingImages(data.images || []);
      setLoading(false);
    };
    fetchPost();
  }, [id, user]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const total = existingImages.length + newImageFiles.length;
    const remaining = 5 - total;
    const selected = Array.from(files).slice(0, remaining);
    setNewImageFiles(prev => [...prev, ...selected.map(file => ({ file, preview: URL.createObjectURL(file) }))]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = async () => {
    if (!user || !id) return;
    if (!title.trim() || !category) { toast.error("শিরোনাম ও ক্যাটাগরি আবশ্যক।"); return; }

    setSubmitting(true);
    try {
      // Upload new images
      const newUrls: string[] = [];
      for (const img of newImageFiles) {
        const ext = img.file.name.split(".").pop() || "jpg";
        const path = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
        const { error } = await supabase.storage.from("post-images").upload(path, img.file);
        if (!error) {
          const { data: urlData } = supabase.storage.from("post-images").getPublicUrl(path);
          newUrls.push(urlData.publicUrl);
        }
      }

      const allImages = [...existingImages, ...newUrls];

      // Re-review: status goes back to pending on edit
      const { error } = await supabase.from("posts").update({
        title: title.trim(),
        description: description.trim(),
        category,
        mode,
        price: mode === "sell" ? parseFloat(price) || 0 : 0,
        want_in_return: mode === "exchange" ? wantInReturn.trim() : "",
        location,
        images: allImages,
        status: "pending", // Re-review on edit
        rejection_reason: "",
      }).eq("id", id).eq("user_id", user.id);

      if (error) throw error;
      toast.success("পোস্ট আপডেট হয়েছে! পুনরায় অ্যাডমিন অনুমোদনের জন্য পাঠানো হয়েছে।");
      navigate("/my-posts");
    } catch (err) {
      toast.error("আপডেট করতে সমস্যা হয়েছে।");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <PageTransition className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
      </PageTransition>
    );
  }

  const totalImages = existingImages.length + newImageFiles.length;

  return (
    <PageTransition className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="text-foreground"><ArrowLeft size={20} /></button>
          <h1 className="text-lg font-semibold text-foreground">পোস্ট এডিট করুন</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-lg">
        {/* Mode */}
        <div className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">পোস্টের ধরন</label>
          <div className="flex gap-2">
            {([
              { value: "sell", label: "বিক্রি", style: "badge-sell" },
              { value: "exchange", label: "এক্সচেঞ্জ", style: "badge-exchange" },
              { value: "free", label: "ফ্রি", style: "badge-free" },
            ] as const).map((m) => (
              <button key={m.value} onClick={() => setMode(m.value)}
                className={`px-4 py-2 rounded-lg text-sm font-medium border-2 transition-all ${mode === m.value ? `${m.style} border-transparent` : "bg-card text-foreground border-border"}`}>
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Images */}
        <div className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">ছবি (সর্বোচ্চ ৫টি)</label>
          <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleImageSelect} />
          <div className="flex gap-2 flex-wrap">
            {existingImages.map((url, i) => (
              <div key={`e-${i}`} className="relative w-20 h-20 rounded-lg overflow-hidden border border-border">
                <img src={url} alt="" className="w-full h-full object-cover" />
                <button onClick={() => setExistingImages(prev => prev.filter((_, idx) => idx !== i))}
                  className="absolute top-0.5 right-0.5 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center">
                  <X size={12} />
                </button>
              </div>
            ))}
            {newImageFiles.map((img, i) => (
              <div key={`n-${i}`} className="relative w-20 h-20 rounded-lg overflow-hidden border border-border">
                <img src={img.preview} alt="" className="w-full h-full object-cover" />
                <button onClick={() => setNewImageFiles(prev => prev.filter((_, idx) => idx !== i))}
                  className="absolute top-0.5 right-0.5 w-5 h-5 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center">
                  <X size={12} />
                </button>
              </div>
            ))}
            {totalImages < 5 && (
              <button onClick={() => fileInputRef.current?.click()}
                className="w-20 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                <ImagePlus size={20} /><span className="text-[10px] mt-0.5">যোগ করুন</span>
              </button>
            )}
          </div>
        </div>

        {/* Title */}
        <div className="mb-4">
          <label className="text-sm font-medium text-foreground mb-1.5 block">শিরোনাম</label>
          <input type="text" value={title} onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring" />
        </div>

        {/* Description */}
        <div className="mb-4">
          <label className="text-sm font-medium text-foreground mb-1.5 block">বিবরণ</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring resize-none" />
        </div>

        {mode === "sell" && (
          <div className="mb-4">
            <label className="text-sm font-medium text-foreground mb-1.5 block">মূল্য (৳)</label>
            <input type="number" value={price} onChange={(e) => setPrice(e.target.value)}
              className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring" />
          </div>
        )}

        {mode === "exchange" && (
          <div className="mb-4">
            <label className="text-sm font-medium text-foreground mb-1.5 block">বিনিময়ে যা চান</label>
            <input type="text" value={wantInReturn} onChange={(e) => setWantInReturn(e.target.value)}
              className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring" />
          </div>
        )}

        {/* Category */}
        <div className="mb-4">
          <label className="text-sm font-medium text-foreground mb-1.5 block">ক্যাটাগরি</label>
          <select value={category} onChange={(e) => setCategory(e.target.value)}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring">
            <option value="">ক্যাটাগরি নির্বাচন করুন</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        {/* Location */}
        <div className="mb-6">
          <label className="text-sm font-medium text-foreground mb-1.5 block"><MapPin size={14} className="inline mr-1" />অবস্থান</label>
          <select value={location} onChange={(e) => setLocation(e.target.value)}
            className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring">
            <option value="">বিভাগ নির্বাচন করুন</option>
            {divisions.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
          <p className="text-xs text-yellow-800">⚠️ এডিট করলে পোস্টটি পুনরায় অ্যাডমিন অনুমোদনের জন্য পাঠানো হবে এবং হোম পেজ থেকে সাময়িকভাবে লুকানো থাকবে।</p>
        </div>

        <button onClick={handleSubmit} disabled={submitting}
          className="w-full bg-primary text-primary-foreground py-3 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
          {submitting ? <><Loader2 size={16} className="animate-spin" /> আপডেট হচ্ছে...</> : "আপডেট করুন"}
        </button>
      </div>
    </PageTransition>
  );
};

export default EditPost;
