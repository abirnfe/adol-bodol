import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Phone, ArrowLeft } from "lucide-react";
import { Eye, EyeOff } from "lucide-react";
import PageTransition from "@/components/PageTransition";

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<"phone" | "reset">("phone");
  const [phone, setPhone] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleCheckPhone = () => {
    if (!phone || phone.length < 11) return alert("সঠিক মোবাইল নম্বর দিন");
    // Mock: always succeed
    setStep("reset");
  };

  const handleReset = () => {
    if (newPassword.length < 6) return alert("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে");
    if (newPassword !== confirmPassword) return alert("পাসওয়ার্ড মিলছে না");
    alert("পাসওয়ার্ড সফলভাবে রিসেট হয়েছে!");
    navigate("/login");
  };

  return (
    <PageTransition className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center mx-auto mb-3">
            <span className="text-primary-foreground font-bold text-2xl">আ</span>
          </div>
          <h1 className="text-2xl font-bold text-foreground">
            {step === "phone" ? "পাসওয়ার্ড ভুলে গেছেন?" : "নতুন পাসওয়ার্ড সেট করুন"}
          </h1>
        </div>

        <div className="bg-card rounded-2xl border border-border p-6 shadow-sm">
          {step === "phone" ? (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">আপনার মোবাইল নম্বর</label>
                <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                  <span className="px-3 text-muted-foreground"><Phone size={16} /></span>
                  <input
                    type="tel"
                    placeholder="01XXXXXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="flex-1 bg-transparent px-2 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none"
                  />
                </div>
              </div>
              <button onClick={handleCheckPhone} className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors">
                পরবর্তী
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">নতুন পাসওয়ার্ড</label>
                <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                  <input type={showNew ? "text" : "password"} placeholder="নতুন পাসওয়ার্ড" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" />
                  <button onClick={() => setShowNew(!showNew)} className="px-3 text-muted-foreground hover:text-foreground">{showNew ? <EyeOff size={16} /> : <Eye size={16} />}</button>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">পাসওয়ার্ড নিশ্চিত করুন</label>
                <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                  <input type={showConfirm ? "text" : "password"} placeholder="আবার পাসওয়ার্ড দিন" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" />
                  <button onClick={() => setShowConfirm(!showConfirm)} className="px-3 text-muted-foreground hover:text-foreground">{showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}</button>
                </div>
              </div>
              <button onClick={handleReset} className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors">
                পাসওয়ার্ড রিসেট করুন
              </button>
            </div>
          )}
          <div className="mt-4 text-center">
            <Link to="/login" className="text-sm text-primary hover:underline">লগইনে ফিরে যান</Link>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default ForgotPassword;
