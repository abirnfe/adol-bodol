import { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import {
  ArrowLeft, User, Phone, MessageSquare, Eye, EyeOff, LogOut, Shield, Star,
  ChevronRight, Award, Edit2, Camera, Loader2
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import PageTransition from "@/components/PageTransition";
import BottomNav from "@/components/BottomNav";
import { toast } from "sonner";

interface ProfileData {
  name: string;
  phone: string;
  whatsapp: string | null;
  avatar_url: string | null;
  points: number;
  is_verified: boolean;
  created_at: string;
}

const compressImage = (file: File, maxWidth = 400, quality = 0.7): Promise<Blob> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ratio = Math.min(maxWidth / img.width, maxWidth / img.height);
        canvas.width = img.width * ratio;
        canvas.height = img.height * ratio;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => resolve(blob!), "image/jpeg", quality);
      };
      img.src = e.target!.result as string;
    };
    reader.readAsDataURL(file);
  });
};

const Profile = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState<"profile" | "password">("profile");
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [whatsapp, setWhatsapp] = useState("");
  const [postsCount, setPostsCount] = useState(0);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (authLoading) return;
    if (!user) { navigate("/login"); return; }
    const fetchProfile = async () => {
      const { data } = await supabase
        .from("profiles")
        .select("name, phone, whatsapp, avatar_url, points, is_verified, created_at")
        .eq("user_id", user.id)
        .single();
      if (data) { setProfile(data); setWhatsapp(data.whatsapp || ""); }
      const { count } = await supabase.from("posts").select("id", { count: "exact", head: true }).eq("user_id", user.id);
      setPostsCount(count || 0);
    };
    fetchProfile();
  }, [user, authLoading, navigate]);

  const handleSaveWhatsapp = async () => {
    if (!user) return;
    await supabase.from("profiles").update({ whatsapp }).eq("user_id", user.id);
    toast.success("সেভ হয়েছে!");
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploadingAvatar(true);
    try {
      const compressed = await compressImage(file);
      const path = `avatars/${user.id}-${Date.now()}.jpg`;
      const { error } = await supabase.storage.from("post-images").upload(path, compressed, { contentType: "image/jpeg", upsert: true });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from("post-images").getPublicUrl(path);
      await supabase.from("profiles").update({ avatar_url: urlData.publicUrl }).eq("user_id", user.id);
      setProfile(prev => prev ? { ...prev, avatar_url: urlData.publicUrl } : prev);
      toast.success("প্রোফাইল ফটো আপডেট হয়েছে!");
    } catch {
      toast.error("ফটো আপলোড করতে সমস্যা হয়েছে।");
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleChangePassword = async () => {
    if (newPassword.length < 6) { toast.error("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে"); return; }
    if (newPassword !== confirmPassword) { toast.error("পাসওয়ার্ড মিলছে না"); return; }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) { toast.error(error.message); return; }
    toast.success("পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!");
    setNewPassword(""); setConfirmPassword("");
  };

  const handleLogout = async () => {
    await signOut();
    toast.success("লগআউট সফল!");
    navigate("/login");
  };

  if (authLoading || (!profile && user)) {
    return (
      <PageTransition className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
      </PageTransition>
    );
  }

  if (!user) return null;

  const joinDate = profile ? new Date(profile.created_at).toLocaleDateString("bn-BD", { year: "numeric", month: "long" }) : "";

  return (
    <PageTransition className="min-h-screen bg-background pb-24">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="text-foreground"><ArrowLeft size={20} /></button>
          <h1 className="text-lg font-semibold text-foreground">প্রোফাইল</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-lg">
        {/* User Card */}
        <div className="bg-card rounded-2xl border border-border p-5 mt-4 text-center relative">
          <div className="relative inline-block">
            {profile?.avatar_url ? (
              <img src={profile.avatar_url} alt="Avatar" className="w-20 h-20 rounded-full object-cover mx-auto" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mx-auto">
                <User size={36} className="text-primary" />
              </div>
            )}
            <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
            <button
              onClick={() => avatarInputRef.current?.click()}
              disabled={uploadingAvatar}
              className="absolute bottom-0 right-0 w-7 h-7 bg-primary rounded-full flex items-center justify-center text-primary-foreground"
            >
              {uploadingAvatar ? <Loader2 size={14} className="animate-spin" /> : <Camera size={14} />}
            </button>
          </div>
          <h2 className="text-lg font-bold text-foreground mt-3">{profile?.name || user.email}</h2>
          <p className="text-sm text-muted-foreground">{profile?.phone || user.email}</p>
          <div className="flex items-center justify-center gap-4 mt-3">
            <div className="text-center">
              <p className="text-lg font-bold text-primary">{profile?.points || 0}</p>
              <p className="text-[11px] text-muted-foreground">পয়েন্ট</p>
            </div>
            <div className="w-px h-8 bg-border" />
            <div className="text-center">
              <p className="text-lg font-bold text-foreground">{postsCount}</p>
              <p className="text-[11px] text-muted-foreground">পোস্ট</p>
            </div>
            <div className="w-px h-8 bg-border" />
            <div className="text-center">
              <p className="text-lg font-bold text-foreground">{joinDate}</p>
              <p className="text-[11px] text-muted-foreground">যোগদান</p>
            </div>
          </div>
          {!profile?.is_verified && (
            <div className="mt-3 inline-flex items-center gap-1 bg-secondary text-secondary-foreground text-xs px-3 py-1 rounded-full">
              <Award size={12} /> ভেরিফাই হতে ৫০০ পয়েন্ট লাগবে
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mt-4">
          <button onClick={() => setActiveTab("profile")}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === "profile" ? "bg-primary text-primary-foreground" : "bg-card text-foreground border border-border"}`}>
            প্রোফাইল
          </button>
          <button onClick={() => setActiveTab("password")}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${activeTab === "password" ? "bg-primary text-primary-foreground" : "bg-card text-foreground border border-border"}`}>
            পাসওয়ার্ড
          </button>
        </div>

        {activeTab === "profile" && (
          <div className="mt-4 space-y-3">
            {/* WhatsApp */}
            <div className="bg-card rounded-xl border border-border p-4">
              <label className="text-sm font-medium text-foreground mb-1.5 block">
                <MessageSquare size={14} className="inline mr-1" /> হোয়াটসঅ্যাপ নম্বর
              </label>
              <div className="flex gap-2">
                <input type="tel" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)}
                  className="flex-1 bg-muted rounded-lg border border-border px-3 py-2 text-sm text-foreground outline-none focus:ring-2 focus:ring-ring" />
                <button onClick={handleSaveWhatsapp}
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">সেভ</button>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1">ক্রেতারা এই নম্বরে WhatsApp করবে</p>
            </div>

            {/* Quick Links */}
            <div className="bg-card rounded-xl border border-border overflow-hidden">
              {[
                { icon: Star, label: "আমার পোস্টসমূহ", desc: `${postsCount}টি পোস্ট`, action: () => navigate("/my-posts") },
                { icon: Star, label: "পয়েন্ট ও রিওয়ার্ড", desc: `${profile?.points || 0} পয়েন্ট আছে`, action: () => {} },
                { icon: Shield, label: "রেফারেল লিংক", desc: "৫০ পয়েন্ট প্রতি রেফারেলে", action: () => {
                  const link = `${window.location.origin}/signup?ref=${user.id.slice(0, 8)}`;
                  navigator.clipboard.writeText(link);
                  toast.success("রেফারেল লিংক কপি হয়েছে!");
                }},
              ].map((item, i) => (
                <button key={i} onClick={item.action}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/50 transition-colors border-b border-border last:border-0">
                  <div className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center">
                    <item.icon size={16} className="text-primary" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium text-foreground">{item.label}</p>
                    <p className="text-[11px] text-muted-foreground">{item.desc}</p>
                  </div>
                  <ChevronRight size={16} className="text-muted-foreground" />
                </button>
              ))}
            </div>

            <button onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 bg-destructive/10 text-destructive py-3 rounded-xl text-sm font-medium hover:bg-destructive/20 transition-colors">
              <LogOut size={16} /> লগআউট
            </button>
          </div>
        )}

        {activeTab === "password" && (
          <div className="mt-4 bg-card rounded-xl border border-border p-4 space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">নতুন পাসওয়ার্ড</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <input type={showNew ? "text" : "password"} placeholder="নতুন পাসওয়ার্ড দিন" value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" />
                <button onClick={() => setShowNew(!showNew)} className="px-3 text-muted-foreground hover:text-foreground">
                  {showNew ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">পাসওয়ার্ড নিশ্চিত করুন</label>
              <div className="flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
                <input type={showConfirm ? "text" : "password"} placeholder="আবার পাসওয়ার্ড দিন" value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none" />
                <button onClick={() => setShowConfirm(!showConfirm)} className="px-3 text-muted-foreground hover:text-foreground">
                  {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button onClick={handleChangePassword}
              className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors">
              পাসওয়ার্ড পরিবর্তন করুন
            </button>
          </div>
        )}
      </div>
      <BottomNav />
    </PageTransition>
  );
};

export default Profile;
