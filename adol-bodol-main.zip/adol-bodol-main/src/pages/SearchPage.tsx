import { useState, useEffect } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, MapPin, Clock, Heart, Search as SearchIcon, PlusCircle, X } from "lucide-react";
import { categories } from "@/components/CategoryGrid";
import PageTransition from "@/components/PageTransition";
import BottomNav from "@/components/BottomNav";

const modeBadge = (mode: string) => {
  const styles: Record<string, string> = { sell: "badge-sell", exchange: "badge-exchange", free: "badge-free" };
  const labels: Record<string, string> = { sell: "বিক্রি", exchange: "এক্সচেঞ্জ", free: "ফ্রি" };
  return <span className={`${styles[mode] || ""} text-[10px] font-semibold px-2 py-0.5 rounded-full`}>{labels[mode] || mode}</span>;
};

const SearchPage = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get("category") || "";
  const [query, setQuery] = useState(searchParams.get("q") || "");
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPosts = async () => {
    setLoading(true);
    let q = supabase
      .from("posts")
      .select("*")
      .eq("status", "approved")
      .order("created_at", { ascending: false });

    if (activeCategory) {
      q = q.eq("category", activeCategory);
    }
    if (query.trim()) {
      q = q.ilike("title", `%${query.trim()}%`);
    }

    const { data } = await q.limit(50);
    setPosts(data ?? []);
    setLoading(false);
  };

  useEffect(() => {
    fetchPosts();
  }, [activeCategory, query]);

  const selectCategory = (catName: string) => {
    const params = new URLSearchParams(searchParams);
    if (catName === activeCategory) {
      params.delete("category");
    } else {
      params.set("category", catName);
    }
    setSearchParams(params);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams(searchParams);
    if (query.trim()) {
      params.set("q", query.trim());
    } else {
      params.delete("q");
    }
    setSearchParams(params);
  };

  const clearFilters = () => {
    setQuery("");
    setSearchParams({});
  };

  return (
    <PageTransition className="min-h-screen bg-background pb-20 md:pb-6">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="text-foreground">
            <ArrowLeft size={20} />
          </button>
          <form onSubmit={handleSearch} className="flex-1 flex items-center bg-muted rounded-lg border border-border focus-within:ring-2 focus-within:ring-ring">
            <input
              type="text"
              placeholder="খুঁজুন..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 bg-transparent px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
            <button type="submit" className="px-3 text-muted-foreground hover:text-primary">
              <SearchIcon size={16} />
            </button>
          </form>
        </div>

        {/* Category Chips */}
        <div className="container mx-auto px-4 pb-2 flex gap-2 overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat.nameEn}
              onClick={() => selectCategory(cat.name)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat.name
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              <cat.icon size={12} />
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 py-4">
        {/* Active filters */}
        {(activeCategory || query) && (
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <span className="text-xs text-muted-foreground">ফিল্টার:</span>
            {activeCategory && (
              <span className="inline-flex items-center gap-1 bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                {activeCategory}
                <button onClick={() => selectCategory(activeCategory)}><X size={10} /></button>
              </span>
            )}
            {query && (
              <span className="inline-flex items-center gap-1 bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded-full">
                "{query}"
                <button onClick={() => { setQuery(""); const p = new URLSearchParams(searchParams); p.delete("q"); setSearchParams(p); }}><X size={10} /></button>
              </span>
            )}
            <button onClick={clearFilters} className="text-xs text-destructive hover:underline">সব মুছুন</button>
          </div>
        )}

        {/* Results */}
        {loading ? (
          <div className="text-center py-12 text-muted-foreground text-sm">লোড হচ্ছে...</div>
        ) : posts.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <SearchIcon size={28} className="text-muted-foreground" />
            </div>
            <h3 className="text-base font-semibold text-foreground mb-1">
              {activeCategory
                ? "এই ক্যাটাগরিতে এখনো কোনো পোস্ট নেই"
                : "কোনো ফলাফল পাওয়া যায়নি"}
            </h3>
            <p className="text-sm text-muted-foreground mb-4">প্রথম পোস্টটি আপনিই করুন!</p>
            <Link
              to="/post"
              className="inline-flex items-center gap-1.5 bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
            >
              <PlusCircle size={16} />
              পোস্ট করুন
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">{posts.length}টি ফলাফল</p>
            {posts.map((post) => (
              <div
                key={post.id}
                className="flex bg-card rounded-xl border border-border hover:border-primary/30 hover:shadow-md transition-all cursor-pointer overflow-hidden"
              >
                <div className="relative w-32 sm:w-40 flex-shrink-0">
                  {post.images?.[0] ? (
                    <img src={post.images[0]} alt={post.title} className="w-full h-full object-cover min-h-[120px]" />
                  ) : (
                    <div className="w-full h-full min-h-[120px] bg-muted flex items-center justify-center text-muted-foreground text-xs">ছবি নেই</div>
                  )}
                  <div className="absolute top-2 left-2">{modeBadge(post.mode)}</div>
                </div>
                <div className="flex-1 p-3 flex flex-col justify-between min-w-0">
                  <div>
                    <h3 className="text-sm font-medium text-foreground line-clamp-2 leading-snug">{post.title}</h3>
                    {post.mode === "exchange" && post.want_in_return && (
                      <p className="text-[11px] text-exchange mt-0.5">চাই: {post.want_in_return}</p>
                    )}
                  </div>
                  <div className="mt-2">
                    {post.mode === "sell" && post.price > 0 && (
                      <p className="text-primary font-bold text-base">৳ {Number(post.price).toLocaleString()}</p>
                    )}
                    {post.mode === "free" && <p className="text-success font-bold text-sm">ফ্রি</p>}
                    {post.mode === "exchange" && <p className="text-exchange font-bold text-sm">এক্সচেঞ্জ</p>}
                    <div className="flex items-center justify-between mt-1">
                      <div className="flex items-center gap-3 text-muted-foreground text-[11px]">
                        {post.location && (
                          <span className="flex items-center gap-0.5"><MapPin size={11} /> {post.location}</span>
                        )}
                        <span className="flex items-center gap-0.5">
                          <Clock size={11} /> {new Date(post.created_at).toLocaleDateString("bn-BD")}
                        </span>
                      </div>
                      <button className="text-muted-foreground hover:text-destructive transition-colors p-1">
                        <Heart size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <BottomNav />
    </PageTransition>
  );
};

export default SearchPage;
