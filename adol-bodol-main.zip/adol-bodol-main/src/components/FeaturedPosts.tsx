import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Star, MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Post {
  id: string;
  title: string;
  price: number | null;
  location: string | null;
  mode: string;
  images: string[] | null;
  is_boosted: boolean;
}

const modeBadge = (mode: string) => {
  const styles: Record<string, string> = { sell: "badge-sell", exchange: "badge-exchange", free: "badge-free" };
  const labels: Record<string, string> = { sell: "বিক্রি", exchange: "এক্সচেঞ্জ", free: "ফ্রি" };
  return (
    <span className={`${styles[mode] || "badge-sell"} text-[10px] font-semibold px-2 py-0.5 rounded-full`}>
      {labels[mode] || mode}
    </span>
  );
};

const priceLabel = (post: Post) => {
  if (post.mode === "free") return "Free";
  if (post.mode === "exchange") return "Exchange";
  return post.price ? `৳ ${post.price.toLocaleString()}` : "৳ 0";
};

const FeaturedPosts = () => {
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    const fetchFeatured = async () => {
      const { data } = await supabase
        .from("posts")
        .select("id, title, price, location, mode, images, is_boosted")
        .eq("status", "approved")
        .eq("is_boosted", true)
        .order("created_at", { ascending: false })
        .limit(10);
      setPosts(data || []);
    };
    fetchFeatured();
  }, []);

  if (posts.length === 0) return null;

  return (
    <section className="container mx-auto px-4 py-4">
      <div className="flex items-center gap-2 mb-4">
        <Star size={18} className="text-accent fill-accent" />
        <h2 className="text-lg font-semibold text-foreground">ফিচার্ড পোস্ট</h2>
        <span className="text-xs text-muted-foreground">(Boosted)</span>
      </div>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {posts.map((item) => (
          <Link
            key={item.id}
            to={`/post/${item.id}`}
            className="flex-shrink-0 w-56 bg-card rounded-xl border-2 border-accent/30 shadow-sm hover:shadow-md transition-shadow cursor-pointer overflow-hidden"
          >
            <div className="relative">
              <img
                src={item.images && item.images.length > 0 ? item.images[0] : "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=200&fit=crop"}
                alt={item.title}
                className="w-full h-32 object-cover"
              />
              <div className="absolute top-2 left-2">{modeBadge(item.mode)}</div>
              <div className="absolute top-2 right-2">
                <span className="bg-accent text-accent-foreground text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5">
                  <Star size={10} className="fill-current" /> BOOST
                </span>
              </div>
            </div>
            <div className="p-3">
              <h3 className="text-sm font-medium text-foreground line-clamp-2 leading-tight">{item.title}</h3>
              <p className="text-primary font-bold text-sm mt-1">{priceLabel(item)}</p>
              {item.location && (
                <div className="flex items-center gap-1 mt-1 text-muted-foreground">
                  <MapPin size={11} />
                  <span className="text-[11px]">{item.location}</span>
                </div>
              )}
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default FeaturedPosts;
