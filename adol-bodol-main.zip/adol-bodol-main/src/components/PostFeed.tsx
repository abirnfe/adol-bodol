import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, Clock, Heart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Post {
  id: string;
  title: string;
  price: number | null;
  location: string | null;
  mode: string;
  want_in_return: string | null;
  images: string[] | null;
  created_at: string;
}

const modeBadge = (mode: string) => {
  const styles: Record<string, string> = { sell: "badge-sell", exchange: "badge-exchange", free: "badge-free" };
  const labels: Record<string, string> = { sell: "বিক্রি", exchange: "এক্সচেঞ্জ", free: "ফ্রি" };
  return (
    <span className={`${styles[mode] || "badge-sell"} text-[10px] font-semibold px-2 py-0.5 rounded-full`}>
      {labels[mode] || mode}
    </span>
  );
};

const timeAgo = (dateStr: string) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins} মিনিট আগে`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} ঘণ্টা আগে`;
  return `${Math.floor(hours / 24)} দিন আগে`;
};

const priceLabel = (post: Post) => {
  if (post.mode === "free") return "Free";
  if (post.mode === "exchange") return "Exchange";
  return post.price ? `৳ ${post.price.toLocaleString()}` : "৳ 0";
};

const PostFeed = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      const { data } = await supabase
        .from("posts")
        .select("id, title, price, location, mode, want_in_return, images, created_at")
        .eq("status", "approved")
        .order("created_at", { ascending: false })
        .limit(20);
      setPosts(data || []);
      setLoading(false);
    };
    fetchPosts();
  }, []);

  if (loading) {
    return (
      <section className="container mx-auto px-4 py-4">
        <h2 className="text-lg font-semibold text-foreground mb-4">সব বিজ্ঞাপন</h2>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-28 bg-muted rounded-xl animate-pulse" />
          ))}
        </div>
      </section>
    );
  }

  if (posts.length === 0) {
    return (
      <section className="container mx-auto px-4 py-4">
        <h2 className="text-lg font-semibold text-foreground mb-4">সব বিজ্ঞাপন</h2>
        <div className="text-center py-12">
          <p className="text-muted-foreground">এখনো কোনো পোস্ট নেই।</p>
          <Link to="/post" className="text-primary text-sm font-medium hover:underline mt-2 inline-block">
            প্রথম পোস্টটি আপনিই করুন!
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section className="container mx-auto px-4 py-4">
      <h2 className="text-lg font-semibold text-foreground mb-4">সব বিজ্ঞাপন</h2>
      <div className="space-y-3">
        {posts.map((post) => (
          <Link
            key={post.id}
            to={`/post/${post.id}`}
            className="flex bg-card rounded-xl border border-border hover:border-primary/30 hover:shadow-md transition-all cursor-pointer overflow-hidden"
          >
            <div className="relative w-32 sm:w-40 flex-shrink-0">
              <img
                src={post.images && post.images.length > 0 ? post.images[0] : "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&h=200&fit=crop"}
                alt={post.title}
                className="w-full h-full object-cover min-h-[120px]"
              />
              <div className="absolute top-2 left-2">{modeBadge(post.mode)}</div>
            </div>
            <div className="flex-1 p-3 flex flex-col justify-between min-w-0">
              <div>
                <h3 className="text-sm font-medium text-foreground line-clamp-2 leading-snug">{post.title}</h3>
                {post.mode === "exchange" && post.want_in_return && (
                  <p className="text-[11px] text-accent mt-0.5">চাই: {post.want_in_return}</p>
                )}
              </div>
              <div className="mt-2">
                <p className="text-primary font-bold text-base">{priceLabel(post)}</p>
                <div className="flex items-center justify-between mt-1">
                  <div className="flex items-center gap-3 text-muted-foreground text-[11px]">
                    {post.location && (
                      <span className="flex items-center gap-0.5">
                        <MapPin size={11} /> {post.location}
                      </span>
                    )}
                    <span className="flex items-center gap-0.5">
                      <Clock size={11} /> {timeAgo(post.created_at)}
                    </span>
                  </div>
                  <button
                    onClick={(e) => e.preventDefault()}
                    className="text-muted-foreground hover:text-destructive transition-colors p-1"
                  >
                    <Heart size={16} />
                  </button>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default PostFeed;
