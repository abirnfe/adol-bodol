import { Smartphone, Laptop, Car, Home, Shirt, Sofa, Briefcase, Gamepad2, BookOpen, MoreHorizontal } from "lucide-react";
import { useNavigate } from "react-router-dom";

export const categories = [
  { name: "মোবাইল", nameEn: "Mobile", icon: Smartphone },
  { name: "ইলেকট্রনিক্স", nameEn: "Electronics", icon: Laptop },
  { name: "গাড়ি", nameEn: "Vehicles", icon: Car },
  { name: "বাড়ি/ফ্ল্যাট", nameEn: "Property", icon: Home },
  { name: "পোশাক", nameEn: "Fashion", icon: Shirt },
  { name: "আসবাবপত্র", nameEn: "Furniture", icon: Sofa },
  { name: "চাকরি", nameEn: "Jobs", icon: Briefcase },
  { name: "গেমিং", nameEn: "Gaming", icon: Gamepad2 },
  { name: "বই", nameEn: "Books", icon: BookOpen },
  { name: "অন্যান্য", nameEn: "Other", icon: MoreHorizontal },
];

const CategoryGrid = () => {
  const navigate = useNavigate();

  return (
    <section className="container mx-auto px-4 py-6">
      <h2 className="text-lg font-semibold text-foreground mb-4">ক্যাটাগরি ব্রাউজ করুন</h2>
      <div className="grid grid-cols-5 sm:grid-cols-5 md:grid-cols-10 gap-3">
        {categories.map((cat) => (
          <button
            key={cat.nameEn}
            onClick={() => navigate(`/search?category=${encodeURIComponent(cat.name)}`)}
            className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-card border border-border hover:border-primary/40 hover:shadow-md transition-all group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center group-hover:bg-primary/10 transition-colors">
              <cat.icon size={20} className="text-primary" />
            </div>
            <span className="text-xs font-medium text-foreground leading-tight text-center">{cat.name}</span>
          </button>
        ))}
      </div>
    </section>
  );
};

export default CategoryGrid;
