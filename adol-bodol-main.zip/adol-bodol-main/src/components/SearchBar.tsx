import { Search, MapPin } from "lucide-react";
import { useState } from "react";

const SearchBar = () => {
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState("সারা বাংলাদেশ");

  return (
    <div className="sticky top-0 z-50 bg-card shadow-sm border-b border-border">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center gap-2">
          {/* Logo */}
          <a href="/" className="flex-shrink-0 mr-2">
            <div className="px-2.5 py-1 rounded-lg bg-green-600 flex items-center justify-center">
              <span className="text-white font-bold text-sm">আদল-বদল</span>
            </div>
          </a>

          {/* Search Input */}
          <div className="flex-1 flex items-center bg-muted rounded-lg overflow-hidden border border-border focus-within:ring-2 focus-within:ring-ring">
            <div className="flex items-center gap-1 px-3 border-r border-border text-muted-foreground text-sm cursor-pointer hover:bg-background/50 py-2.5">
              <MapPin size={14} />
              <span className="hidden md:inline">{location}</span>
            </div>
            <input
              type="text"
              placeholder="আপনি কী খুঁজছেন? (Search...)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
            <button className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2.5 transition-colors">
              <Search size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchBar;
