import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle, XCircle, Eye, MapPin, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

const AdminPosts = () => {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectId, setRejectId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [viewPost, setViewPost] = useState<any | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const fetchPosts = async () => {
    setLoading(true);
    const { data: postsData } = await supabase
      .from("posts")
      .select("*")
      .eq("status", "pending")
      .order("created_at", { ascending: false });

    if (postsData && postsData.length > 0) {
      const userIds = [...new Set(postsData.map(p => p.user_id))];
      const { data: profilesData } = await supabase
        .from("profiles")
        .select("user_id, name, phone")
        .in("user_id", userIds);
      
      const profileMap = new Map((profilesData ?? []).map(p => [p.user_id, p]));
      const merged = postsData.map(post => ({
        ...post,
        profiles: profileMap.get(post.user_id) || null,
      }));
      setPosts(merged);
    } else {
      setPosts([]);
    }
    setLoading(false);
  };

  useEffect(() => { fetchPosts(); }, []);

  const approve = async (id: string) => {
    await supabase.from("posts").update({ status: "approved" }).eq("id", id);
    fetchPosts();
  };

  const reject = async () => {
    if (!rejectId) return;
    await supabase.from("posts").update({ status: "rejected", rejection_reason: rejectReason }).eq("id", rejectId);
    setRejectId(null);
    setRejectReason("");
    fetchPosts();
  };

  const adminDelete = async () => {
    if (!deleteId) return;
    await supabase.from("posts").delete().eq("id", deleteId);
    setDeleteId(null);
    toast.success("পোস্ট ডিলিট হয়েছে!");
    fetchPosts();
  };

  const modeBadge = (mode: string) => {
    const styles: Record<string, string> = { sell: "badge-sell", exchange: "badge-exchange", free: "badge-free" };
    const labels: Record<string, string> = { sell: "বিক্রি", exchange: "এক্সচেঞ্জ", free: "ফ্রি" };
    return <span className={`${styles[mode] || ''} text-[10px] font-semibold px-2 py-0.5 rounded-full`}>{labels[mode] || mode}</span>;
  };

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="space-y-3">
      <h2 className="text-sm font-semibold text-foreground">অপেক্ষমাণ পোস্ট ({posts.length})</h2>

      {posts.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <CheckCircle size={40} className="mx-auto mb-2 text-success" />
          <p className="text-sm">সব পোস্ট পর্যালোচনা হয়ে গেছে!</p>
        </div>
      )}

      {posts.map((post) => (
        <div key={post.id} className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="flex">
            {post.images?.[0] && (
              <img src={post.images[0]} alt="" className="w-28 h-28 object-cover flex-shrink-0" />
            )}
            <div className="p-3 flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    {modeBadge(post.mode)}
                    <span className="text-[10px] text-muted-foreground">{post.category}</span>
                  </div>
                  <h3 className="text-sm font-medium text-foreground line-clamp-1">{post.title}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{post.description}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground">
                <span>{post.profiles?.name || "Unknown"} • {post.profiles?.phone}</span>
                {post.location && <span className="flex items-center gap-0.5"><MapPin size={10} />{post.location}</span>}
              </div>
              {post.mode === "sell" && post.price > 0 && (
                <p className="text-sm font-bold text-primary mt-1">৳ {Number(post.price).toLocaleString()}</p>
              )}
              {post.mode === "exchange" && post.want_in_return && (
                <p className="text-[11px] text-exchange mt-1">চাই: {post.want_in_return}</p>
              )}
            </div>
          </div>
          <div className="flex gap-2 p-3 pt-0">
            <button onClick={() => approve(post.id)} className="flex-1 flex items-center justify-center gap-1.5 bg-success text-success-foreground py-2 rounded-lg text-xs font-medium hover:opacity-90">
              <CheckCircle size={14} /> অনুমোদন
            </button>
            <button onClick={() => setRejectId(post.id)} className="flex-1 flex items-center justify-center gap-1.5 bg-destructive text-destructive-foreground py-2 rounded-lg text-xs font-medium hover:opacity-90">
              <XCircle size={14} /> প্রত্যাখ্যান
            </button>
            <button onClick={() => setViewPost(post)} className="px-3 py-2 rounded-lg text-xs font-medium bg-muted text-muted-foreground">
              <Eye size={14} />
            </button>
            <button onClick={() => setDeleteId(post.id)} className="px-3 py-2 rounded-lg text-xs font-medium bg-destructive/10 text-destructive">
              <Trash2 size={14} />
            </button>
          </div>
        </div>
      ))}

      {/* Reject Modal */}
      {rejectId && (
        <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-2xl border border-border p-5 w-full max-w-sm animate-scale-in">
            <h3 className="text-sm font-semibold text-foreground mb-3">প্রত্যাখ্যানের কারণ</h3>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="কারণ লিখুন..."
              rows={3}
              className="w-full bg-muted rounded-lg border border-border px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none mb-3"
            />
            <div className="flex gap-2">
              <button onClick={() => { setRejectId(null); setRejectReason(""); }} className="flex-1 py-2 rounded-lg text-sm bg-muted text-muted-foreground">বাতিল</button>
              <button onClick={reject} className="flex-1 py-2 rounded-lg text-sm bg-destructive text-destructive-foreground font-medium">প্রত্যাখ্যান</button>
            </div>
          </div>
        </div>
      )}

      {/* View Modal */}
      {viewPost && (
        <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4" onClick={() => setViewPost(null)}>
          <div className="bg-card rounded-2xl border border-border p-5 w-full max-w-md max-h-[80vh] overflow-y-auto animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-base font-semibold text-foreground mb-2">{viewPost.title}</h3>
            {viewPost.images?.length > 0 && (
              <div className="flex gap-2 overflow-x-auto mb-3">
                {viewPost.images.map((img: string, i: number) => (
                  <img key={i} src={img} alt="" className="w-32 h-24 object-cover rounded-lg flex-shrink-0" />
                ))}
              </div>
            )}
            <p className="text-sm text-foreground mb-2">{viewPost.description}</p>
            <div className="text-xs text-muted-foreground space-y-1">
              <p>ক্যাটাগরি: {viewPost.category}</p>
              <p>মোড: {viewPost.mode}</p>
              {viewPost.price > 0 && <p>মূল্য: ৳ {Number(viewPost.price).toLocaleString()}</p>}
              {viewPost.want_in_return && <p>চাই: {viewPost.want_in_return}</p>}
              <p>লোকেশন: {viewPost.location}</p>
              <p>পোস্টার: {viewPost.profiles?.name} ({viewPost.profiles?.phone})</p>
            </div>
            <button onClick={() => setViewPost(null)} className="w-full mt-4 py-2 rounded-lg text-sm bg-muted text-foreground font-medium">বন্ধ করুন</button>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <Dialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>পোস্ট ডিলিট</DialogTitle>
            <DialogDescription>এই পোস্টটি স্থায়ীভাবে ডিলিট করতে চান?</DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2">
            <button onClick={() => setDeleteId(null)} className="flex-1 py-2 rounded-lg border border-border text-sm text-foreground">বাতিল</button>
            <button onClick={adminDelete} className="flex-1 py-2 rounded-lg bg-destructive text-destructive-foreground text-sm font-semibold">ডিলিট</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminPosts;
