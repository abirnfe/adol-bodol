import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AlertTriangle, Trash2, CheckCircle, Eye } from "lucide-react";

const AdminReports = () => {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchReports = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("reports")
      .select("*, posts(title, images, user_id, profiles:profiles!posts_user_id_fkey(name))")
      .eq("status", "pending")
      .order("created_at", { ascending: false });
    setReports(data ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchReports(); }, []);

  const deletePost = async (postId: string, reportId: string) => {
    await supabase.from("posts").delete().eq("id", postId);
    fetchReports();
  };

  const dismissReport = async (reportId: string) => {
    await supabase.from("reports").update({ status: "dismissed" }).eq("id", reportId);
    fetchReports();
  };

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="space-y-3">
      <h2 className="text-sm font-semibold text-foreground">রিপোর্টেড পোস্ট ({reports.length})</h2>

      {reports.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <CheckCircle size={40} className="mx-auto mb-2 text-success" />
          <p className="text-sm">কোনো রিপোর্ট নেই!</p>
        </div>
      )}

      {reports.map((report) => (
        <div key={report.id} className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle size={16} className="text-warning mt-0.5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-medium text-foreground">{report.posts?.title || "Deleted Post"}</h3>
              <p className="text-xs text-muted-foreground mt-0.5">পোস্টার: {report.posts?.profiles?.name || "Unknown"}</p>
              <div className="mt-2 bg-destructive/5 rounded-lg p-2">
                <p className="text-xs text-destructive font-medium">রিপোর্টের কারণ:</p>
                <p className="text-xs text-foreground">{report.reason}</p>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">
                {new Date(report.created_at).toLocaleDateString("bn-BD")}
              </p>
            </div>
          </div>
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => deletePost(report.post_id, report.id)}
              className="flex-1 flex items-center justify-center gap-1.5 bg-destructive text-destructive-foreground py-2 rounded-lg text-xs font-medium hover:opacity-90"
            >
              <Trash2 size={12} /> পোস্ট মুছুন
            </button>
            <button
              onClick={() => dismissReport(report.id)}
              className="flex-1 flex items-center justify-center gap-1.5 bg-muted text-muted-foreground py-2 rounded-lg text-xs font-medium hover:bg-muted/80"
            >
              <CheckCircle size={12} /> রিপোর্ট বাতিল
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AdminReports;
