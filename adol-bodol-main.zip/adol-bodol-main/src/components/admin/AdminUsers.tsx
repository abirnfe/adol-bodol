import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Users, Ban, UserCheck, AlertTriangle, Send, Search, Plus, Minus } from "lucide-react";

const AdminUsers = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [warningUserId, setWarningUserId] = useState<string | null>(null);
  const [warningMsg, setWarningMsg] = useState("");
  const [pointsUserId, setPointsUserId] = useState<string | null>(null);
  const [pointsAmount, setPointsAmount] = useState(0);

  const fetchUsers = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });
    setUsers(data ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchUsers(); }, []);

  const toggleBan = async (userId: string, currentBan: boolean) => {
    await supabase.from("profiles").update({ is_banned: !currentBan }).eq("user_id", userId);
    fetchUsers();
  };

  const sendWarning = async () => {
    if (!warningUserId || !warningMsg.trim()) return;
    await supabase.from("warnings").insert({ user_id: warningUserId, message: warningMsg });
    setWarningUserId(null);
    setWarningMsg("");
    alert("সতর্কতা পাঠানো হয়েছে ✅");
  };

  const adjustPoints = async (add: boolean) => {
    if (!pointsUserId || pointsAmount <= 0) return;
    const user = users.find(u => u.user_id === pointsUserId);
    if (!user) return;
    const newPoints = add ? user.points + pointsAmount : Math.max(0, user.points - pointsAmount);
    await supabase.from("profiles").update({ points: newPoints }).eq("user_id", pointsUserId);
    setPointsUserId(null);
    setPointsAmount(0);
    fetchUsers();
  };

  const filtered = users.filter(u =>
    u.name?.toLowerCase().includes(search.toLowerCase()) ||
    u.phone?.includes(search)
  );

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="space-y-3">
      {/* Search */}
      <div className="flex items-center bg-muted rounded-lg border border-border px-3 gap-2">
        <Search size={16} className="text-muted-foreground" />
        <input
          type="text"
          placeholder="নাম বা নম্বর খুঁজুন..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 bg-transparent py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none"
        />
      </div>

      <h2 className="text-sm font-semibold text-foreground">সব ইউজার ({filtered.length})</h2>

      {/* User Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="text-left px-3 py-2 text-xs font-medium text-muted-foreground">নাম</th>
                <th className="text-left px-3 py-2 text-xs font-medium text-muted-foreground">ফোন</th>
                <th className="text-center px-3 py-2 text-xs font-medium text-muted-foreground">পয়েন্ট</th>
                <th className="text-center px-3 py-2 text-xs font-medium text-muted-foreground">স্ট্যাটাস</th>
                <th className="text-right px-3 py-2 text-xs font-medium text-muted-foreground">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((user) => (
                <tr key={user.id} className="border-b border-border last:border-0 hover:bg-muted/30">
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center">
                        <Users size={12} className="text-primary" />
                      </div>
                      <span className="text-foreground font-medium">{user.name || "—"}</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground text-xs">{user.phone || "—"}</td>
                  <td className="px-3 py-2.5 text-center text-foreground font-medium">{user.points}</td>
                  <td className="px-3 py-2.5 text-center">
                    {user.is_banned ? (
                      <span className="text-[10px] bg-destructive/10 text-destructive px-2 py-0.5 rounded-full font-medium">ব্যানড</span>
                    ) : (
                      <span className="text-[10px] bg-success/10 text-success px-2 py-0.5 rounded-full font-medium">সক্রিয়</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setWarningUserId(user.user_id)}
                        className="p-1.5 rounded-md bg-warning/10 text-warning hover:bg-warning/20 transition-colors"
                        title="সতর্কতা"
                      >
                        <AlertTriangle size={12} />
                      </button>
                      <button
                        onClick={() => setPointsUserId(user.user_id)}
                        className="p-1.5 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                        title="পয়েন্ট"
                      >
                        <Plus size={12} />
                      </button>
                      <button
                        onClick={() => toggleBan(user.user_id, user.is_banned)}
                        className={`p-1.5 rounded-md transition-colors ${
                          user.is_banned
                            ? "bg-success/10 text-success hover:bg-success/20"
                            : "bg-destructive/10 text-destructive hover:bg-destructive/20"
                        }`}
                        title={user.is_banned ? "আনব্যান" : "ব্যান"}
                      >
                        {user.is_banned ? <UserCheck size={12} /> : <Ban size={12} />}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Warning Modal */}
      {warningUserId && (
        <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-2xl border border-border p-5 w-full max-w-sm animate-scale-in">
            <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5 mb-3">
              <AlertTriangle size={14} className="text-warning" /> সতর্কতা পাঠান
            </h3>
            <textarea
              value={warningMsg}
              onChange={(e) => setWarningMsg(e.target.value)}
              placeholder="সতর্কতা বার্তা লিখুন..."
              rows={3}
              className="w-full bg-muted rounded-lg border border-border px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none mb-3"
            />
            <div className="flex gap-2">
              <button onClick={() => { setWarningUserId(null); setWarningMsg(""); }} className="flex-1 py-2 rounded-lg text-sm bg-muted text-muted-foreground">বাতিল</button>
              <button onClick={sendWarning} className="flex-1 py-2 rounded-lg text-sm bg-warning text-warning-foreground font-medium flex items-center justify-center gap-1">
                <Send size={12} /> পাঠান
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Points Modal */}
      {pointsUserId && (
        <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-2xl border border-border p-5 w-full max-w-sm animate-scale-in">
            <h3 className="text-sm font-semibold text-foreground mb-3">পয়েন্ট ম্যানেজমেন্ট</h3>
            <input
              type="number"
              value={pointsAmount}
              onChange={(e) => setPointsAmount(Number(e.target.value))}
              placeholder="পয়েন্ট সংখ্যা"
              className="w-full bg-muted rounded-lg border border-border px-3 py-2 text-sm text-foreground outline-none mb-3"
            />
            <div className="flex gap-2">
              <button onClick={() => setPointsUserId(null)} className="py-2 px-4 rounded-lg text-sm bg-muted text-muted-foreground">বাতিল</button>
              <button onClick={() => adjustPoints(true)} className="flex-1 py-2 rounded-lg text-sm bg-success text-success-foreground font-medium flex items-center justify-center gap-1">
                <Plus size={12} /> যোগ
              </button>
              <button onClick={() => adjustPoints(false)} className="flex-1 py-2 rounded-lg text-sm bg-destructive text-destructive-foreground font-medium flex items-center justify-center gap-1">
                <Minus size={12} /> বিয়োগ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminUsers;
