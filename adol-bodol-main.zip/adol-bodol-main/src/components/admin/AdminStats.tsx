import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { BarChart3, FileText, Users, AlertTriangle } from "lucide-react";

const AdminStats = () => {
  const [stats, setStats] = useState({ users: 0, totalPosts: 0, pending: 0, approved: 0, reported: 0 });

  useEffect(() => {
    const fetchStats = async () => {
      const [profilesRes, postsRes, pendingRes, approvedRes, reportsRes] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("posts").select("id", { count: "exact", head: true }),
        supabase.from("posts").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("posts").select("id", { count: "exact", head: true }).eq("status", "approved"),
        supabase.from("reports").select("id", { count: "exact", head: true }).eq("status", "pending"),
      ]);
      setStats({
        users: profilesRes.count ?? 0,
        totalPosts: postsRes.count ?? 0,
        pending: pendingRes.count ?? 0,
        approved: approvedRes.count ?? 0,
        reported: reportsRes.count ?? 0,
      });
    };
    fetchStats();
  }, []);

  const cards = [
    { label: "মোট ইউজার", value: stats.users, icon: Users, color: "text-primary" },
    { label: "মোট পোস্ট", value: stats.totalPosts, icon: FileText, color: "text-foreground" },
    { label: "অপেক্ষমাণ", value: stats.pending, icon: BarChart3, color: "text-warning" },
    { label: "রিপোর্টেড", value: stats.reported, icon: AlertTriangle, color: "text-destructive" },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {cards.map((c) => (
        <div key={c.label} className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2 mb-2">
            <c.icon size={16} className={c.color} />
            <span className="text-xs text-muted-foreground">{c.label}</span>
          </div>
          <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
        </div>
      ))}
    </div>
  );
};

export default AdminStats;
