import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Bell, Send, Trash2, ToggleLeft, ToggleRight } from "lucide-react";

const AdminNotices = () => {
  const [notices, setNotices] = useState<any[]>([]);
  const [newNotice, setNewNotice] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchNotices = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("notices")
      .select("*")
      .order("created_at", { ascending: false });
    setNotices(data ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchNotices(); }, []);

  const publish = async () => {
    if (!newNotice.trim()) return;
    await supabase.from("notices").insert({ message: newNotice, is_active: true });
    setNewNotice("");
    fetchNotices();
  };

  const toggleActive = async (id: string, current: boolean) => {
    await supabase.from("notices").update({ is_active: !current }).eq("id", id);
    fetchNotices();
  };

  const deleteNotice = async (id: string) => {
    await supabase.from("notices").delete().eq("id", id);
    fetchNotices();
  };

  return (
    <div className="space-y-4">
      {/* Create Notice */}
      <div className="bg-card rounded-xl border border-border p-4">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5 mb-3">
          <Bell size={14} className="text-primary" /> নতুন গ্লোবাল নোটিশ
        </h3>
        <textarea
          value={newNotice}
          onChange={(e) => setNewNotice(e.target.value)}
          placeholder='যেমন: "আমরা ডেভেলপার নিয়োগ দিচ্ছি!" বা "নতুন আপডেট"'
          rows={3}
          className="w-full bg-muted rounded-lg border border-border px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none mb-3"
        />
        <button
          onClick={publish}
          className="w-full flex items-center justify-center gap-1.5 bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors"
        >
          <Send size={14} /> প্রকাশ করুন
        </button>
      </div>

      {/* Existing Notices */}
      <h3 className="text-sm font-semibold text-foreground">সকল নোটিশ ({notices.length})</h3>
      {notices.map((notice) => (
        <div key={notice.id} className="bg-card rounded-xl border border-border p-4 flex items-start justify-between gap-3">
          <div className="flex-1">
            <p className="text-sm text-foreground">{notice.message}</p>
            <p className="text-[10px] text-muted-foreground mt-1">
              {new Date(notice.created_at).toLocaleDateString("bn-BD")}
              {" • "}
              {notice.is_active ? (
                <span className="text-success font-medium">সক্রিয়</span>
              ) : (
                <span className="text-muted-foreground">নিষ্ক্রিয়</span>
              )}
            </p>
          </div>
          <div className="flex gap-1.5">
            <button
              onClick={() => toggleActive(notice.id, notice.is_active)}
              className="p-1.5 rounded-md bg-muted hover:bg-muted/80 text-muted-foreground transition-colors"
            >
              {notice.is_active ? <ToggleRight size={14} className="text-success" /> : <ToggleLeft size={14} />}
            </button>
            <button
              onClick={() => deleteNotice(notice.id)}
              className="p-1.5 rounded-md bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AdminNotices;
