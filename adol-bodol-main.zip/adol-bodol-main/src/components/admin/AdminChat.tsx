import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MessageSquare, Send, Users } from "lucide-react";

interface Conversation {
  user_id: string;
  name: string;
  phone: string;
  lastMessage: string;
  lastTime: string;
  unread: number;
}

const AdminChat = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [reply, setReply] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchConversations = async () => {
    setLoading(true);
    const { data: msgs } = await supabase
      .from("support_messages")
      .select("*")
      .order("created_at", { ascending: false });

    if (!msgs) { setLoading(false); return; }

    // Fetch profiles separately
    const userIds = [...new Set(msgs.map(m => m.user_id))];
    const { data: profiles } = await supabase
      .from("profiles")
      .select("user_id, name, phone")
      .in("user_id", userIds);
    
    const profileMap: Record<string, { name: string; phone: string }> = {};
    for (const p of profiles ?? []) {
      profileMap[p.user_id] = { name: p.name, phone: p.phone };
    }

    const grouped: Record<string, Conversation> = {};
    for (const m of msgs) {
      if (!grouped[m.user_id]) {
        grouped[m.user_id] = {
          user_id: m.user_id,
          name: profileMap[m.user_id]?.name || "Unknown",
          phone: profileMap[m.user_id]?.phone || "",
          lastMessage: m.message,
          lastTime: m.created_at,
          unread: 0,
        };
      }
      if (!m.is_read && m.sender === "user") grouped[m.user_id].unread++;
    }
    setConversations(Object.values(grouped));
    setLoading(false);
  };

  const fetchMessages = async (userId: string) => {
    setSelectedUserId(userId);
    const { data } = await supabase
      .from("support_messages")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: true });
    setMessages(data ?? []);
    // Mark as read
    await supabase
      .from("support_messages")
      .update({ is_read: true })
      .eq("user_id", userId)
      .eq("sender", "user")
      .eq("is_read", false);
    fetchConversations();
  };

  const sendReply = async () => {
    if (!reply.trim() || !selectedUserId) return;
    await supabase.from("support_messages").insert({
      user_id: selectedUserId,
      message: reply,
      sender: "admin",
    });
    setReply("");
    fetchMessages(selectedUserId);
  };

  useEffect(() => { fetchConversations(); }, []);

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="flex gap-3 h-[60vh]">
      {/* Conversation List */}
      <div className="w-64 bg-card rounded-xl border border-border overflow-hidden flex-shrink-0">
        <div className="px-3 py-2 border-b border-border">
          <h3 className="text-xs font-semibold text-foreground">কথোপকথন</h3>
        </div>
        <div className="overflow-y-auto h-full">
          {conversations.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-6">কোনো মেসেজ নেই</p>
          )}
          {conversations.map((c) => (
            <button
              key={c.user_id}
              onClick={() => fetchMessages(c.user_id)}
              className={`w-full flex items-start gap-2 px-3 py-2.5 border-b border-border text-left hover:bg-muted/50 transition-colors ${
                selectedUserId === c.user_id ? "bg-muted" : ""
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                <Users size={14} className="text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium text-foreground truncate">{c.name}</p>
                  {c.unread > 0 && (
                    <span className="w-4 h-4 bg-destructive text-destructive-foreground text-[9px] rounded-full flex items-center justify-center flex-shrink-0">
                      {c.unread}
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground truncate">{c.lastMessage}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 bg-card rounded-xl border border-border flex flex-col overflow-hidden">
        {!selectedUserId ? (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <MessageSquare size={32} className="mx-auto mb-2" />
              <p className="text-sm">একটি কথোপকথন নির্বাচন করুন</p>
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === "admin" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[70%] px-3 py-2 rounded-xl text-sm ${
                      msg.sender === "admin"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    <p>{msg.message}</p>
                    {msg.image_url && (
                      <img src={msg.image_url} alt="" className="mt-1 rounded-lg max-w-full" />
                    )}
                    <p className={`text-[9px] mt-0.5 ${msg.sender === "admin" ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                      {new Date(msg.created_at).toLocaleTimeString("bn-BD", { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-border p-3 flex gap-2">
              <input
                type="text"
                value={reply}
                onChange={(e) => setReply(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendReply()}
                placeholder="উত্তর লিখুন..."
                className="flex-1 bg-muted rounded-lg border border-border px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none"
              />
              <button
                onClick={sendReply}
                className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default AdminChat;
