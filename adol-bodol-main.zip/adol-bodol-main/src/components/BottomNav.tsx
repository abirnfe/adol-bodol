import { Home, Search, PlusCircle, Heart, User } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const navItems = [
  { icon: Home, label: "হোম", path: "/" },
  { icon: Search, label: "খুঁজুন", path: "/search" },
  { icon: PlusCircle, label: "পোস্ট", path: "/post", highlight: true },
  { icon: Heart, label: "পছন্দ", path: "/favorites" },
  { icon: User, label: "প্রোফাইল", path: "/profile" },
];

const BottomNav = () => {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 md:hidden">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-0.5 px-3 py-1 transition-colors ${
                item.highlight
                  ? ""
                  : isActive
                  ? "text-primary"
                  : "text-muted-foreground"
              }`}
            >
              {item.highlight ? (
                <div className="w-11 h-11 -mt-5 rounded-full bg-primary flex items-center justify-center shadow-lg">
                  <item.icon size={22} className="text-primary-foreground" />
                </div>
              ) : (
                <item.icon size={20} />
              )}
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
