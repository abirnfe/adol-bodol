import { Bell, MessageSquare, PlusCircle, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";

const Header = () => {
  const { user, isAdmin } = useAuth();
  return (
    <header className="hidden md:block bg-card border-b border-border">
      <div className="container mx-auto px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center gap-2">
            <div className="px-3 py-1.5 rounded-xl bg-green-600 flex items-center justify-center">
              <span className="text-white font-bold text-lg">আদল-বদল</span>
            </div>
          </Link>
          <nav className="flex items-center gap-4 text-sm">
            <Link to="/" className="text-foreground font-medium hover:text-primary transition-colors">হোম</Link>
            <Link to="/search" className="text-muted-foreground hover:text-primary transition-colors">ক্যাটাগরি</Link>
            <Link to="/profile" className="text-muted-foreground hover:text-primary transition-colors">প্রোফাইল</Link>
            {isAdmin && (
              <Link to="/admin" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">
                <Shield size={14} /> অ্যাডমিন
              </Link>
            )}
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <button className="p-2 text-muted-foreground hover:text-foreground transition-colors relative">
            <Bell size={20} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
          </button>
          <button className="p-2 text-muted-foreground hover:text-foreground transition-colors">
            <MessageSquare size={20} />
          </button>
          <Link
            to="/post"
            className="flex items-center gap-1.5 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            <PlusCircle size={16} />
            পোস্ট করুন
          </Link>
          <Link
            to="/login"
            className="text-sm font-medium text-foreground hover:text-primary transition-colors"
          >
            লগইন
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;
